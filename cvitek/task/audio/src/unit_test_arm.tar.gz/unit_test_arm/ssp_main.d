/home/vincentyu/mars/freertos/cvitek/task/audio/src/unit_test_arm/ssp_main.o: \
 /home/vincentyu/mars/freertos/cvitek/task/audio/src/unit_test_arm/ssp_main.c \
 ../SSP_Algorithm_20211202/tmwtypes.h \
 ../SSP_Algorithm_20211202/mmse_init.h ../SSP_Algorithm_20211202/struct.h \
 ../SSP_Algorithm_20211202/define.h ../SSP_Algorithm_20211202/mmse.h \
 ../SSP_Algorithm_20211202/define.h ../SSP_Algorithm_20211202/struct.h \
 ../SSP_Algorithm_20211202/agc_init.h ../SSP_Algorithm_20211202/agc.h \
 ../SSP_Algorithm_20211202/lpaec.h ../SSP_Algorithm_20211202/packfft.h \
 ../SSP_Algorithm_20211202/nlpaes.h ../SSP_Algorithm_20211202/notch.h \
 ../SSP_Algorithm_20211202/dc.h ../SSP_Algorithm_20211202/dg.h \
 ../SSP_Algorithm_20211202/delay.h ../SSP_Algorithm_20211202/functrl.h \
 /home/vincentyu/mars/freertos/cvitek/task/audio/src/unit_test_arm/ssp_unit_test.h \
 /home/vincentyu/mars/freertos/cvitek/task/audio/src/unit_test_arm/../unit_test/incbin.h
