/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 *%
 *%       ssp_main.c
 *%       Author: Sharon Lee
 *%       History:
 *%                       Created by Sharon Lee for NR in August, 2019
 *%                       Add AGC by Sharon Lee in December, 2019
 *%                       Add Linear Processing AEC by Sharon Lee in April, 2020
 *%                       Add Nonlinear Processing AES by Sharon Lee in August, 2020
 *%                       Add Notch Filter and DC Filter by Sharon Lee in April, 2021
 *%                       Add SPK-path AGC by Sharon Lee in July, 2021
 *%                       Add DG and Delay by Sharon Lee in November, 2021
 *%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

/*************************************************************************************/
/* This example C main file shows how to call entry-point functions and read input signals. 	   */
/* You must customize this file for your development environment/platform. 				   */
/* Modify it and integrate it into your own development environment/platform.                          	   */
/*                                                                       									   				   */
/*************************************************************************************/

/* Include files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "tmwtypes.h"
#include "mmse_init.h"
#include "mmse.h"
#include "define.h"
#include "struct.h"
#include "agc_init.h"
#include "agc.h"
#include "lpaec.h"
#include "packfft.h"
#include "nlpaes.h"
#include "notch.h"
#include "dc.h"
#include "dg.h"
#include "delay.h"
#include "functrl.h"

#define INPUT_FILE_AS_ARG 1
FILE *fp_test_ne_mic_in;
FILE *fp_test_fe_ref_in;
FILE *fp_test_ne_out;
FILE *fp_test_fe_in;
FILE *fp_test_fe_out;

#if INPUT_FILE_AS_ARG
char *mic_ne_filename;
char *mic_fe_filename;
char *spk_in_filename;
int customer_option;
#endif
//#define SHARON_DEBUG
#ifdef SHARON_DEBUG
FILE *fp_test;
long long frame_cnt = 0;
long long debug_cnt = 0;
#endif


/* Function Declarations */
static void SSP_Algorithm(void);
/* Function Definitions */
static void SSP_Algorithm(void)
{

  float fs;    /* sampling rate */
  int hopsize = 160;    /* input hop size */
  int len = 2*hopsize;    /* window size */
  int len1 = len/2;    /* overlap size */
  int nFFT = 2*len;

  /* Delay History Buffer */
  DelayState *delay_state = NULL;

  /* DG History Buffer */
  static dg_struct dg_obj;

  /* DC Filter History Buffer */
  static dcfilter_struct dc_obj;

  /* Notch Filter History Buffer */
  static qfilter_struct notch_obj;
  static int notch_state[4];

  /* LP AEC History Buffer */
  LinearEchoState *aec_state = NULL;
  short filter_length, init_filter_length;

  /* NLP AES History Buffer */
  NonLinearEchoState *aes_state = NULL;
  boolean_T st_vad;
  float std_thrd;
  float aes_supp_coef1;
  float aes_supp_coef2;

  /* NR History Buffer */
  short x_old[160];    /* input overlap buffer */
  float y_old[160];    /* output OLA buffer */
  float Xk_prev[321];    /* estimated clean speech power */
  float noise_mean[321];    /* noise mean */
  float noise_mu2[321];    /* estimated noise power */
  float amp_inst_band[5*3];
  float noisy_st_trough[5];
  float noisy_st_peak[5];
  float amp_inst_sum_hist[3];
  float vad_slope_cnt;
  float vad_slope;
  float vad_dr_cnt;
  float vad_dr;
  float vad_mmse;
  float vad_mmse_cnt;
  boolean_T speech_vad;
  float frame;
  float eta;
  float ksi_min;
  float vad_mmse_cnt_para;
  float initial_noise_pow_time;
  float nr_frame1_last_sample = 0;
  int nenr_silence_time, nenr_silence_cnt;

  /* AGC History Buffer */
  static agc_struct agc_obj;

  /* Near-end Input/Output Buffer */
  short ne_mic_fixed_in[320];        /* near-end and fixed-point mic input */
  float ne_mic_float_in[320];          /* near-end and floating-point mic input */
  short fe_ref_fixed_in[320];          /* far-end and fixed-point ref input */
  float ne_float_out[160];                 /* near-end and floating-point output */
  short ne_fixed_out[160];              /* near-end and fixed-point output */
  float tmp = 0;
  float alpha = 0;
  float alpha2 = 0;

  /* For Test */
  short wav_header[44];
  short cond1, cond2, cond3, cond4, cond5, cond6;
  int i;
  /* Far-end Input/Output Buffer */
  short fe_fixed_in[160];                  /* far-end and fixed-point input */
  short fe_fixed_out[160];               /* far-end and fixed-point output */

  /* AGC History Buffer in SPK Path */
  static agc_struct spk_agc_obj;




/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
/*%*/
/*% SSP Algorithm Parameter */
/*%*/
/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/

  static ssp_para_struct ssp_para_obj;
  /* SSP algorithm parameter need to be adjusted according to different prototype machine from client */
  /* {0: default}, {1: CEOP}, {2: HT master (ref hw)}, {3: HT slave (ref hw)}, {4: ZT (ref sw)} */
  ssp_para_obj.para_client_config = 0;    /* for choosing client's prototype machine, [0, 4] */
#if INPUT_FILE_AS_ARG
  ssp_para_obj.para_client_config = customer_option;
  printf("input_file_as_arg option[%d]\n", customer_option);
#endif

  speech_vad = speech_vad;
  /* Assign Parameter Value to SSP Algorithm */
  /* These values of parameters need to be adjusted according to the actual field try on prototype machine of client, these parameters can be pulled out to be API input arguments for SDK */
  if (1 == ssp_para_obj.para_client_config) {
  ssp_para_obj.para_fun_config = 60;
  ssp_para_obj.para_delay_sample = 1;
  ssp_para_obj.para_dg_target = 1;
  ssp_para_obj.para_aec_init_filter_len = 2;
  ssp_para_obj.para_aec_filter_len = 13;
  ssp_para_obj.para_aes_std_thrd = 37;
  ssp_para_obj.para_aes_supp_coeff = 60;
  ssp_para_obj.para_nr_init_sile_time = 0;
  ssp_para_obj.para_nr_snr_coeff = 10;
  ssp_para_obj.para_agc_max_gain = 0;
  ssp_para_obj.para_agc_target_high = 2;
  ssp_para_obj.para_agc_target_low = 6;
  ssp_para_obj.para_agc_vad_ena = 1;
  ssp_para_obj.para_notch_freq = 1;
  ssp_para_obj.para_spk_fun_config = 0;
  ssp_para_obj.para_spk_agc_max_gain = 0;
  ssp_para_obj.para_spk_agc_target_high = 8;
  ssp_para_obj.para_spk_agc_target_low = 72;
  } else if (2 == ssp_para_obj.para_client_config) {
  ssp_para_obj.para_fun_config = 15;
  ssp_para_obj.para_delay_sample = 1;
  ssp_para_obj.para_dg_target = 1;
  ssp_para_obj.para_aec_init_filter_len = 2;
  ssp_para_obj.para_aec_filter_len = 13;
  ssp_para_obj.para_aes_std_thrd = 37;
  ssp_para_obj.para_aes_supp_coeff = 60;
  ssp_para_obj.para_nr_init_sile_time = 0;
  ssp_para_obj.para_nr_snr_coeff = 15;
  ssp_para_obj.para_agc_max_gain = 0;
  ssp_para_obj.para_agc_target_high = 18;
  ssp_para_obj.para_agc_target_low = 66;
  ssp_para_obj.para_agc_vad_ena = 1;
  ssp_para_obj.para_notch_freq = 0;
  ssp_para_obj.para_spk_fun_config = 0;
  ssp_para_obj.para_spk_agc_max_gain = 0;
  ssp_para_obj.para_spk_agc_target_high = 8;
  ssp_para_obj.para_spk_agc_target_low = 72;
  } else if (3 == ssp_para_obj.para_client_config) {
  ssp_para_obj.para_fun_config = 15;
  ssp_para_obj.para_delay_sample = 1;
  ssp_para_obj.para_dg_target = 1;
  ssp_para_obj.para_aec_init_filter_len = 1;
  ssp_para_obj.para_aec_filter_len = 2;
  ssp_para_obj.para_aes_std_thrd = 37;
  ssp_para_obj.para_aes_supp_coeff = 60;
  ssp_para_obj.para_nr_init_sile_time = 0;
  ssp_para_obj.para_nr_snr_coeff = 15;
  ssp_para_obj.para_agc_max_gain = 0;
  ssp_para_obj.para_agc_target_high = 15;
  ssp_para_obj.para_agc_target_low = 15;
  ssp_para_obj.para_agc_vad_ena = 1;
  ssp_para_obj.para_notch_freq = 0;
  ssp_para_obj.para_spk_fun_config = 0;
  ssp_para_obj.para_spk_agc_max_gain = 0;
  ssp_para_obj.para_spk_agc_target_high = 8;
  ssp_para_obj.para_spk_agc_target_low = 72;
  } else if (4 == ssp_para_obj.para_client_config) {
  ssp_para_obj.para_fun_config = 207;
  ssp_para_obj.para_delay_sample = 450;
  ssp_para_obj.para_dg_target = 6;
  ssp_para_obj.para_aec_init_filter_len = 13;
  ssp_para_obj.para_aec_filter_len = 13;
  ssp_para_obj.para_aes_std_thrd = 37;
  ssp_para_obj.para_aes_supp_coeff = 60;
  ssp_para_obj.para_nr_init_sile_time = 0;
  ssp_para_obj.para_nr_snr_coeff = 15;
  ssp_para_obj.para_agc_max_gain = 0;
  ssp_para_obj.para_agc_target_high = 2;
  ssp_para_obj.para_agc_target_low = 72;
  ssp_para_obj.para_agc_vad_ena = 1;
  ssp_para_obj.para_notch_freq = 0;
  ssp_para_obj.para_spk_fun_config = 1;
  ssp_para_obj.para_spk_agc_max_gain = 0;
  ssp_para_obj.para_spk_agc_target_high = 8;
  ssp_para_obj.para_spk_agc_target_low = 72;
  } else {
  ssp_para_obj.para_fun_config = 15;
  ssp_para_obj.para_delay_sample = 1;
  ssp_para_obj.para_dg_target = 1;
  ssp_para_obj.para_aec_init_filter_len = 2;
  ssp_para_obj.para_aec_filter_len = 13;
  ssp_para_obj.para_aes_std_thrd = 37;
  ssp_para_obj.para_aes_supp_coeff = 60;
  ssp_para_obj.para_nr_init_sile_time = 0;
  ssp_para_obj.para_nr_snr_coeff = 15;
  ssp_para_obj.para_agc_max_gain = 0;
  ssp_para_obj.para_agc_target_high = 2;
  ssp_para_obj.para_agc_target_low = 72;
  ssp_para_obj.para_agc_vad_ena = 1;
  ssp_para_obj.para_notch_freq = 0;
  ssp_para_obj.para_spk_fun_config = 1;
  ssp_para_obj.para_spk_agc_max_gain = 0;
  ssp_para_obj.para_spk_agc_target_high = 8;
  ssp_para_obj.para_spk_agc_target_low = 72;
  }


/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
/*% */
/*% SSP Algorithm Applied to MIC Path */
/*% */
/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/
#if !(INPUT_FILE_AS_ARG)
  if ((fp_test_ne_mic_in = fopen("./pattern/mic/zt/NE_zt_ref_sw_8k_1.wav", "rb")) == NULL) {
  	printf("Cannot open input file \n");
  	exit(2);
  }
  if ((fp_test_fe_ref_in = fopen("./pattern/mic/zt/FE_zt_ref_sw_8k_1.wav", "rb")) == NULL) {
  	printf("Cannot open input file \n");
  	exit(2);
  }
  if ((fp_test_ne_out = fopen("./pattern/mic/zt/mic_ssp_zt_ref_sw_8k_1.pcm", "wb")) == NULL) {
  	printf("Cannot open output file \n");
  	exit(2);
  }
#endif

  #ifdef SHARON_DEBUG
  	fp_test = fopen("./pattern/test.txt", "wb");
  #endif


  /* Get the sampling rate from CODEC configuration if run with system codes */
  fread(&wav_header[0], 1, 44, fp_test_fe_ref_in);    /* wav header */
  fread(&wav_header[0], 1, 44, fp_test_ne_mic_in);    /* wav header */
  fs = (float)(wav_header[12]);    /* sampling rate recorded in 24th byte with 4-byte length, little endian */
  #ifdef SHARON_DEBUG
  if ((fs != 8000.0F) && (fs != 16000.0F))
      printf("Input is not wave format \n");
  #endif


  cond1 = ssp_para_obj.para_fun_config & DELAY_ENABLE;
  if (cond1) {
  	delay_para(&ssp_para_obj);
	delay_state = delay_init(&ssp_para_obj);
  }

  cond1 = ssp_para_obj.para_fun_config & DG_ENABLE;
  if (cond1) {
  	DG_para(&dg_obj, &ssp_para_obj);
  }

  cond1 = ssp_para_obj.para_fun_config & DCREMOVER_ENABLE;
  if (cond1) {
  	DC_remover_init(&dc_obj, fs);
  }

  cond1 = ssp_para_obj.para_fun_config & NOTCH_ENABLE;
  if (cond1) {
  	notch_para(&notch_obj, &ssp_para_obj, fs);
  	notch_init(&notch_obj, notch_state);
  }

  cond1 = ssp_para_obj.para_fun_config & LP_AEC_ENABLE;
  cond2 = ssp_para_obj.para_fun_config & NLP_AES_ENABLE;
  if (cond1 | cond2) {
  	LP_AEC_para(&ssp_para_obj, &filter_length, &init_filter_length);    /* creates parameters for linear acoustic echo canceller */
  	aec_state = LP_AEC_init(hopsize, filter_length, init_filter_length, x_old, fs);    /* creates AEC state */
  }
  if (cond2) {
  	NLP_AES_para(&ssp_para_obj, &std_thrd, &aes_supp_coef1, &aes_supp_coef2);    /* creates parameters for nonlinear acoustic echo suppression */
  	aes_state = NLP_AES_init(hopsize, fs, std_thrd, aes_supp_coef1, aes_supp_coef2);    /* creates AES state */
  	aes_state->echo_state = aec_state;
  }

  cond1 = ssp_para_obj.para_fun_config & NR_ENABLE;
  cond2 = ssp_para_obj.para_fun_config & AGC_ENABLE;
  if (cond1 | cond2 | ssp_para_obj.para_agc_vad_ena) {
  	NR_para(&ssp_para_obj, fs, &nenr_silence_time);    /* assign value to NR parameters */
  	NR_init(&frame, x_old, y_old, Xk_prev, noise_mean, noise_mu2, &vad_slope_cnt, &vad_slope, amp_inst_band,
			&vad_dr_cnt, &vad_dr, noisy_st_trough, noisy_st_peak, &vad_mmse, &vad_mmse_cnt, amp_inst_sum_hist,
			&eta, &ksi_min, fs, &vad_mmse_cnt_para, &initial_noise_pow_time, &nenr_silence_cnt);    /* initialize NR input arguments */
  }
  if (cond2) {
  	AGC_para(&agc_obj, &ssp_para_obj, 1);    /* assign value to AGC parameters */
  	AGC_init(&agc_obj, &ssp_para_obj, fs, hopsize, 1);    /* initialize AGC input arguments */
  }

  speech_vad = true;    /* default */
  st_vad = false;    /* default */
  frame = 1.0F;    /* set initial value here in case of NR off */
  nenr_silence_cnt = 0;
  ssp_para_obj.para_nr_init_sile_time = MIN(MAX(ssp_para_obj.para_nr_init_sile_time, 0), 250);
  if (fs == 16000.0F) {
  	initial_noise_pow_time = 14;
  	nenr_silence_time = ssp_para_obj.para_nr_init_sile_time*2;
  } else {
  	initial_noise_pow_time = 7;
  	nenr_silence_time = ssp_para_obj.para_nr_init_sile_time;
  }


  for (;;)	/* Main Frame Loop in MIC Path */
  {
	/* This section of codes have to be replaced by reading the bitstream from system layer in real platform */
	cond1 = fread(&ne_mic_fixed_in[0], sizeof(short), hopsize, fp_test_ne_mic_in);    /* get current near-end frame data */
	cond2 = fread(&fe_ref_fixed_in[0], sizeof(short), hopsize, fp_test_fe_ref_in);    /* get current far-end frame data */
	if ((cond1 != hopsize) | (cond2 != hopsize)) {
		cond1 = ssp_para_obj.para_fun_config & LP_AEC_ENABLE;
		cond2 = ssp_para_obj.para_fun_config & NLP_AES_ENABLE;
		cond3 = ssp_para_obj.para_fun_config & NR_ENABLE;
  		cond4 = ssp_para_obj.para_fun_config & AGC_ENABLE;
		cond6 = ssp_para_obj.para_fun_config & DELAY_ENABLE;
		if (cond1 | cond2) {
			LP_AEC_free(aec_state);
		}
		if (cond2) {
      if (aec_state != NULL)
			  NLP_AES_free(aes_state);
		}
		if (cond3 | cond4) {
			speech_fft_free(nr_fft_table);
		}
		if (cond6) {
			delay_free(delay_state);
		}
		fclose(fp_test_ne_mic_in);
		fclose(fp_test_fe_ref_in);
		fclose(fp_test_ne_out);
		#ifdef SHARON_DEBUG
		fclose(fp_test);
		#endif
		goto Pattern_EOF;
	}

	if (2 == ssp_para_obj.para_client_config) {
		for (i = 0; i < hopsize; i++) {
			tmp = (float)(fe_ref_fixed_in[i])/(float)(32768.0F) * 15.84F;
  			tmp = MIN(MAX(tmp, -1.0F), 1.0F);
  			fe_ref_fixed_in[i] = ROUND_POS(tmp*(short)(32767));
			ne_mic_fixed_in[i] = ROUND_POS(((float)(ne_mic_fixed_in[i])/(float)(32768.0F) * 0.5F)*(short)(32767));
		}
	}

	if (!(ssp_para_obj.para_fun_config)) {
		for (i = 0; i < hopsize; i++)
			ne_fixed_out[i] = ne_mic_fixed_in[i];    /* save MCPS if all off */
	} else {

		/* Delay ref signal frame-by-frame processing */
		cond1 = ssp_para_obj.para_fun_config & DELAY_ENABLE;
		if (cond1) {
			delay_ref(fe_ref_fixed_in, delay_state, hopsize);
		}

		/* Apply DG frame-by-frame processing */
		cond1 = ssp_para_obj.para_fun_config & DG_ENABLE;
		if (cond1) {
			apply_DG(ne_mic_fixed_in, ne_mic_fixed_in, &dg_obj, hopsize);
		}

		/* DC filter frame-by-frame processing */
		cond1 = ssp_para_obj.para_fun_config & DCREMOVER_ENABLE;
		if (cond1) {
			DC_remover(ne_mic_fixed_in, ne_mic_fixed_in, &dc_obj, hopsize);
		}

		/* Notch filter frame-by-frame processing */
		cond1 = ssp_para_obj.para_fun_config & NOTCH_ENABLE;
		if (cond1) {
			notch_filter(ne_mic_fixed_in, ne_mic_fixed_in, &notch_obj, hopsize);
		}

		/* Linear AEC frame-by-frame processing */
		cond1 = ssp_para_obj.para_fun_config & LP_AEC_ENABLE;
		cond2 = ssp_para_obj.para_fun_config & NLP_AES_ENABLE;
		if (cond1 | cond2) {
			LP_AEC(aec_state, ne_mic_fixed_in, fe_ref_fixed_in, ne_fixed_out);
			if (cond2) {
				for (i = 0; i < hopsize; i++)
					aes_state->aes_std_in[i] = ne_mic_fixed_in[i];
			}
		}

		if (cond1 | cond2) {
			for (i = 0; i < hopsize; i++) {
				ne_mic_fixed_in[i] = x_old[i];
				ne_mic_fixed_in[i+hopsize] = ne_fixed_out[i];
			}
		} else {
			for (i = 0; i < hopsize; i++) {
				ne_mic_fixed_in[i+hopsize] = ne_mic_fixed_in[i];    /* go first to avoid overwriting by x_old[] */
				ne_mic_fixed_in[i] = x_old[i];
			}
		}
		for (i = 0; i < hopsize; i++)
			x_old[i] = ne_mic_fixed_in[i+hopsize];    /* update input overlap data */

		cond3 = ssp_para_obj.para_fun_config & NR_ENABLE;
		cond4 = ssp_para_obj.para_fun_config & AGC_ENABLE;
		if (!(cond2 | cond3 | cond4)) {
			/* Compensate DG frame-by-frame processing */
			cond1 = ssp_para_obj.para_fun_config & DG_ENABLE;
			if (cond1) {
				compen_DG(&ne_mic_fixed_in[hopsize], &ne_mic_fixed_in[hopsize], &dg_obj, hopsize);
			}
			for (i = 0; i < hopsize; i++)
				ne_fixed_out[i] = ne_mic_fixed_in[hopsize + i];    /* save MCPS if NR+AES+AGC off */
		} else {
			/*  Transform to floating-point with float precision for input signals, input sample have to be 16-bit length */
			for (i = 0; i < len; i++) {
				ne_mic_float_in[i] = (float)(ne_mic_fixed_in[i])/(float)(32768.0F);
			}

			if (cond3 | ssp_para_obj.para_agc_vad_ena) {
				/* Stationary NR frame-by-frame processing */
				if (nenr_silence_cnt >= nenr_silence_time) {
					NR(ne_mic_float_in, (float)len, (float)len1, (float)nFFT, &frame, y_old, Xk_prev, noise_mean, noise_mu2, &vad_slope_cnt, &vad_slope,
						amp_inst_band, &vad_dr_cnt, &vad_dr, noisy_st_trough, noisy_st_peak, &vad_mmse, &vad_mmse_cnt, amp_inst_sum_hist, fs, eta, ksi_min,
						vad_mmse_cnt_para, initial_noise_pow_time, ne_float_out, &speech_vad);
					if (1 == (unsigned short)frame)
						nr_frame1_last_sample = ne_float_out[hopsize-1];
					if (2 == (unsigned short)frame) {
						alpha2 = 1.0F/160.0F;
						alpha = 1 - alpha2;
						ne_float_out[0] = alpha * nr_frame1_last_sample + alpha2 * ne_float_out[0];
						for (i = 0; i < hopsize-1; i++) {
							alpha2 = (float)(1.0F + i)/160.0F;
							alpha = 1 - alpha2;
							ne_float_out[i+1] = alpha * ne_float_out[i] + alpha2 * ne_float_out[i+1];
						}
					}
				} else {
					for (i = 0; i < hopsize; i++) {
						ne_float_out[i] = 0.0F;
					}
				}
			}

			if (cond3) {
				/*  Transform to fixed-point with 16-bit length for output */
				for (i = 0; i < hopsize; i++) {
					ne_float_out[i] = MIN(MAX(ne_float_out[i], -1.0F), 1.0F);    /* saturation protection to avoid overflow */
					if (ne_float_out[i] < 0.0F)
						ne_fixed_out[i] = ROUND_NEG(ne_float_out[i]*(int)(32768));
					else
						ne_fixed_out[i] = ROUND_POS(ne_float_out[i]*(short)(32767));
				}
			} else {
				for (i = 0; i < hopsize; i++)
					ne_fixed_out[i] = ne_mic_fixed_in[hopsize + i];
			}

			/* Nonlinear AES frame-by-frame processing */
			if (cond2) {
				NLP_AES(aes_state, ne_fixed_out, frame, speech_vad);
				st_vad = (boolean_T)aes_state->st_vad;
			}

			if (2 == ssp_para_obj.para_client_config) {
				for (i = 0; i < hopsize; i++) {
					tmp = (float)(ne_fixed_out[i])/(float)(32768.0F) * 1.9952F;
					tmp = MIN(MAX(tmp, -1.0F), 1.0F);
					ne_fixed_out[i] = ROUND_POS(tmp*(short)(32767));
				}
			}

			/* Compensate DG frame-by-frame processing */
			cond1 = ssp_para_obj.para_fun_config & DG_ENABLE;
			if (cond1) {
				compen_DG(ne_fixed_out, ne_fixed_out, &dg_obj, hopsize);
			}

			/* AGC frame-by-frame processing */
			if (cond4) {
				AGC(ne_fixed_out, ne_fixed_out, &agc_obj, &ssp_para_obj, speech_vad, st_vad, nenr_silence_time, nenr_silence_cnt, 1);
			}

		}
	}

	if (nenr_silence_cnt < nenr_silence_time)
		nenr_silence_cnt += 1;
	else
		nenr_silence_cnt = nenr_silence_time + 1;    /* avoid overflow */

	if (nenr_silence_cnt > nenr_silence_time) {
		if (frame < initial_noise_pow_time)
			frame += 1;
		else
			frame = initial_noise_pow_time + 1;
	}

	fwrite(&ne_fixed_out[0], sizeof(short), hopsize, fp_test_ne_out);

	#ifdef SHARON_DEBUG
	frame_cnt++;
	if (frame_cnt == 500) {
		printf(" ");
		//fclose(fp_test_ne_out);
	}
	#endif

  }

  Pattern_EOF:
    printf("Test Pattern EOF in MIC Path!\n");    /* EOF, set breakpoint here for VC++ version */


/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
/*% */
/*% SSP Algorithm Applied to SPK Path */
/*% */
/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/
#if !(INPUT_FILE_AS_ARG)
  if ((fp_test_fe_in = fopen("./pattern/spk/FE_8k_1.wav", "rb")) == NULL) {
  	printf("Cannot open input file \n");
  	exit(2);
  }
  if ((fp_test_fe_out = fopen("./pattern/spk/spk_ssp_8k_1.pcm", "wb")) == NULL) {
  	printf("Cannot open output file \n");
  	exit(2);
  }
#endif


  /* Get the sampling rate from CODEC configuration if run with system codes */
  fread(&wav_header[0], 1, 44, fp_test_fe_in);    /* wav header */
  fs = (float)(wav_header[12]);    /* sampling rate recorded in 24th byte with 4-byte length, little endian */
  #ifdef SHARON_DEBUG
  if ((fs != 8000.0F) && (fs != 16000.0F))
      printf("Input is not wave format \n");
  #endif

  cond5 = ssp_para_obj.para_spk_fun_config & SPK_AGC_ENABLE;
  if (cond5) {
	AGC_para(&spk_agc_obj, &ssp_para_obj, 2);    /* assign value to spk-path AGC parameters */
	AGC_init(&spk_agc_obj, &ssp_para_obj, fs, hopsize, 2);    /* initialize spk-path AGC input arguments */
  }


  for (;;)	/* Main Frame Loop in SPK Path */
  {
	/* This section of codes have to be replaced by reading the bitstream from system layer in real platform */
	cond5 = fread(&fe_fixed_in[0], sizeof(short), hopsize, fp_test_fe_in);    /* get current far-end frame data */
	if ((cond5 != hopsize)) {
		fclose(fp_test_fe_in);
		fclose(fp_test_fe_out);
		goto FE_Pattern_EOF;
	}

	/* AGC frame-by-frame processing in spk path */
	cond5 = ssp_para_obj.para_spk_fun_config & SPK_AGC_ENABLE;
	if (cond5) {
		AGC(fe_fixed_in, fe_fixed_out, &spk_agc_obj, &ssp_para_obj, true, false, 0, 0, 2);
	}

	fwrite(&fe_fixed_out[0], sizeof(short), hopsize, fp_test_fe_out);
  }

  FE_Pattern_EOF:
    printf("Test Pattern EOF in SPK Path!\n");    /* EOF, set breakpoint here for VC++ version */

}

#if INPUT_FILE_AS_ARG
static void _ssp_main_usage(void)
{
  printf("-----------------ssp main 20211202 usage -----------------\n");
  printf("=============================================================\n");
  printf("input arg 1: NE file\n");
  printf("input arg 2: FE file\n");
  printf("input arg 3: SPK input test file\n");
  printf("ssp main will produce , near end result and spk result\n");
  printf("=============================================================\n");
}
#endif

int main(int argc, char * const argv[])
{
#ifndef INPUT_FILE_AS_ARG
  (void)argc;
  (void)argv;
#else
  if (argc < 4) {
    printf("Need more input arguements ssp algo 20211202!!!\n");
    _ssp_main_usage();
    return -1;
  }
#if 0
FILE *fp_test_ne_mic_in;
FILE *fp_test_fe_ref_in;
FILE *fp_test_ne_out;
FILE *fp_test_fe_in;
FILE *fp_test_fe_out;

char *mic_ne_filename;
char *mic_fe_filename;
char *spk_in_filename;
#endif
  mic_ne_filename = argv[1];
  if (access(mic_ne_filename, 0) < 0) {
    printf("[Error]file name for mic_ne not exist[%s]\n", mic_ne_filename);
    return -1;
  }
  if ((fp_test_ne_mic_in = fopen(mic_ne_filename, "rb")) == NULL) {
    printf("[Error]Cannot open input file NE\n");
    return -1;
  }

  mic_fe_filename = argv[2];
  if (access(mic_fe_filename, 0) < 0) {
    printf("[Error]file name for mic_fe not exist[%s]\n", mic_fe_filename);
    return -1;
  }
  if ((fp_test_fe_ref_in = fopen(mic_fe_filename, "rb")) == NULL) {
    printf("[Error]Cannot open input file FE\n");
    return -1;
  }

  spk_in_filename = argv[3];
  if (access(spk_in_filename, 0) < 0) {
    printf("[Error]file name for SPK IN  not exist[%s]\n", spk_in_filename);
    return -1;
  }
  if ((fp_test_fe_in = fopen(spk_in_filename, "rb")) == NULL) {
    printf("[Error]Cannot open input file FE for spk\n");
    return -1;
  }
  //setup the output filename
  if ((fp_test_ne_out = fopen("mic_output.pcm", "wb")) == NULL) {
  	printf("Cannot open output file \n");
  	exit(2);
  }

  if ((fp_test_fe_out = fopen("spk_output.pcm", "wb")) == NULL) {
  printf("Cannot open output file \n");
  exit(2);
  }
    /* {0: default}, {1: CEOP}, {2: HT master (ref hw)}, {3: HT slave (ref hw)}, {4: ZT (ref sw)} */
  printf("input customer option:\n");
  printf("{0: default}, {1: CEOP}, {2: HT master (ref hw)}, {3: HT slave (ref hw)}, {4: ZT (ref sw)} :\n\t");
  scanf("%d", &customer_option);
  printf("Your option is[%d]\n", customer_option);
#endif

  SSP_Algorithm();

  return 0;
}


